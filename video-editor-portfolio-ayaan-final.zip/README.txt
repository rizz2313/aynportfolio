VIDEO EDITING PORTFOLIO
Open index.html in a browser.

Quick customization:
1. Replace every "Your Name" with your name.
2. Replace your@email.com with your email.
3. Replace the image URLs with your own showreel/portfolio thumbnails.
4. Change the maroon colors at the top of the CSS if you want a different shade.

The layout is designed to closely reproduce the supplied mobile reference:
dark navy background, rounded cards, sticky header, hero/showreel, stats, animated skill bars,
centered portfolio carousel, testimonials, and CTA — with the blue accent changed to maroon.
